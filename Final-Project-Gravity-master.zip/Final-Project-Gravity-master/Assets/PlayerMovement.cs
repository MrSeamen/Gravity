﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerMovement : MonoBehaviour
{
    [SerializeField] float moveSpeed = 5f;
    private CharacterController charactermove; 
    // Start is called before the first frame update
    void Start()
    {
        charactermove = transform.GetComponent<CharacterController>();
    }

    // Update is called once per frame
    void Update()
    {
        float x = Input.GetAxis("Horizontal") * moveSpeed;
        float y = Input.GetAxis("Vertical") * moveSpeed;
        Vector3 movement = new Vector3(x, 0, y);
        movement = Vector3.ClampMagnitude(movement, moveSpeed);
        movement = movement * Time.deltaTime;
        movement = transform.TransformVector(movement);
        charactermove.Move(movement);
    }
}
